<?php

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

// Classe personnalisée pour afficher les Scroll Motion
class Scroll_Motion_List_Table extends WP_List_Table {

    // Constructeur
    public function __construct() {
        parent::__construct([
            'singular' => 'scroll_motion', // Nom singulier pour une ligne
            'plural'   => 'scroll_motion', // Nom pluriel pour plusieurs lignes
            'ajax'     => false // Pas d'AJAX pour ce tableau
        ]);
    }

    // Définir les colonnes
    public function get_columns() {
        $columns = [
            'cb'            => '<input type="checkbox" />', // Colonne de case à cocher pour les actions en lot
            'title'         => 'Title',
            'shortcode_id'  => 'Shortcode Id',
            'date'          => 'Date',
            'author'        => 'Author',
            'published_status'        => 'Status',
            'images'        => 'Image'
        ];
        return $columns;
    }

    // Définir les colonnes triables
    public function get_sortable_columns() {
        $sortable_columns = [
            'title' => ['title', true], // Tri par titre
            'date' => ['date', false],
        ];
        return $sortable_columns;
    }

    // Préparer les éléments du tableau
    public function prepare_items() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'scroll_motion';
    
        // Pagination
        $per_page = 10;
        $current_page = $this->get_pagenum();
    
        // Récupérer le terme de recherche s'il est défini
        $search = isset($_POST['s']) ? trim($_POST['s']) : '';
    
        // Vérifier le statut sélectionné dans le filtre
        $status_filter = isset($_GET['published_status']) ? $_GET['published_status'] : 'all';
    
        // Construire la clause WHERE en fonction du filtre de statut
        $where = '1=1';
        if ($status_filter === 'published') {
            $where .= " AND published_status = 1";
        } elseif ($status_filter === 'draft') {
            $where .= " AND published_status = 0";
        }
    
        // Ajoutez la condition de recherche
        if (!empty($search)) {
            $where .= $wpdb->prepare(" AND title LIKE %s", '%' . $wpdb->esc_like($search) . '%');
        }
    
        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name WHERE $where");
    
        // Récupération des éléments
        $this->items = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE $where LIMIT %d OFFSET %d",
            $per_page,
            ($current_page - 1) * $per_page
        ), ARRAY_A);
    
        $this->_column_headers = [$this->get_columns(), [], $this->get_sortable_columns()];
    
        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);
    }    

    // Message à afficher si aucun élément n'est trouvé
    public function no_items() {
        _e('Aucune Scroll Motion trouvée.', 'scroll-animation-video');
    }
    
    // Affichage des colonnes
    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'title':
            case 'shortcode_id':
                return '[scroll_motion shortcode_id="'.$item[$column_name].'"]';
            case 'author':
                return $item[$column_name];
            case 'date':
                $text = "";
                if($item['modified_verification'] === "0") {
                    $text .= "Published ".date('d/m/Y H:i', strtotime($item['date']));
                } else {
                    $text .= "Last Modified ".date('d/m/Y H:i', strtotime($item['date']));
                }
                return $text;
            case 'published_status':
                return $item[$column_name] === "1" ? 'Published' : 'Draft';
            case 'images':
                $images = explode(',', $item['images']);
                $output = '';
                $output .= '<img src="' . esc_url($images[0]) . '" style="width:64px; margin-right:5px; height: 64px; object-fit: cover; object-position: center;" />';
                return $output;
            default:
                return print_r($item, true); // Affiche toute la ligne pour le débogage
        }
    }

    // Colonne de case à cocher pour les actions de groupe
    public function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="scroll_motion[]" value="%s" />',
            $item['id']
        );
    }

    // Colonne Titre avec actions (modifier, supprimer)
    public function column_title($item) {
        $actions = [
            'edit' => sprintf('<a style="color: #135e96;" href="?page=add-or-edit&edit_id=%d">Edit</a>', $item['id']),
            'quick_edit' => sprintf('<span style="color: #135e96;cursor:pointer;" class="quick-edit" data-id="%s" data-title="%s" data-status="%s">Quick Edit</span>', $item['id'], esc_attr($item['title']), esc_attr($item['published_status'])),
            'delete' => sprintf('<a href="#" class="delete-action" data-id="%s">Delete</a>', $item['id']),
            'duplicate' => sprintf('<a style="color: #135e96;" href="#" class="duplicate-action" data-id="%s">Duplicate</a>', $item['id']),
        ];
    
        // On met le titre dans un span avec une classe identifiable
        $title_html = sprintf('<span class="scroll-motion-title">%s</span>', $item['title']);
    
        return sprintf('%1$s %2$s', $title_html, $this->row_actions($actions));
    }       

    public function get_bulk_actions(){
        return [
            'delete' 	=> __( 'Delete', 'jst' ),
        ];
    }

    // Méthode pour définir les filtres
    function get_views() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'scroll_motion';
    
        // Compter le nombre d'éléments pour chaque statut
        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
        $published_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name WHERE published_status = 1");
        $draft_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name WHERE published_status = 0");

        // Définir le filtre actuel (par défaut : 'all')
        $current_status = isset($_GET['published_status']) ? $_GET['published_status'] : 'all';

        // Définir les vues pour chaque filtre
        $views = array(
            'all' => sprintf(
                '<a href="%s" class="%s">All <span class="count">(%d) | </span></a>',
                remove_query_arg('published_status'),
                $current_status === 'all' ? 'current' : '',
                $total_items
            ),
            'published' => sprintf(
                '<a href="%s" class="%s">Published <span class="count">(%d) | </span></a>',
                add_query_arg('published_status', 'published'),
                $current_status === 'published' ? 'current' : '',
                $published_items
            ),
            'draft' => sprintf(
                '<a href="%s" class="%s">Draft <span class="count">(%d)</span></a>',
                add_query_arg('published_status', 'draft'),
                $current_status === 'draft' ? 'current' : '',
                $draft_items
            ),
        );

        // Retourner les vues avec des séparateurs visuels
        return $views;
    }
}
